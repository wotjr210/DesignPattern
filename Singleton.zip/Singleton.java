package Singleton;

/**
 * CLass Name : Singleton
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-28     wotjr    최초생성
 */

public class Singleton {
    private static Singleton uniqueInstance;

    private Singleton() {
    } // 생성자를 pirvate로 선언했기 때문에 Singleton 클래스에서만 인스턴스 생성

    public static Singleton getInstance(){
        if( uniqueInstance == null ){
            uniqueInstance = new Singleton();
            /*  lazy instantiation (게이른 인스턴스 생성)
                객체가 필요한 상황이 닥치기전에는 인스턴스를 생성하지않음.
             */
        }
        return uniqueInstance;
    }
}

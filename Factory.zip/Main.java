package Factory;

/**
 * CLass Name : Main
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-19     wotjr    최초생성
 */

public class Main {
    public static void main(String[] args) {

        PizzaStore nyPizzaStore = new NYPizzaStore();
        nyPizzaStore.orderPizza("cheese");

        PizzaStore chicagoPizzaStore = new ChicagoPizzaStore();
        chicagoPizzaStore.orderPizza("cheese");
    }
}

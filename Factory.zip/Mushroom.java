package Factory;

/**
 * CLass Name : Mushroom
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-20     wotjr    최초생성
 */

public class Mushroom implements Veggies {
    public Mushroom() {
        System.out.println("Add Mushroom Toppings.");
    }
}

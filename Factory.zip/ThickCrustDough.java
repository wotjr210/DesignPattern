package Factory;

/**
 * CLass Name : ThickCrustDough
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-20     wotjr    최초생성
 */

public class ThickCrustDough implements Dough {

    public ThickCrustDough() {
        System.out.println("Add ThickCrustDough Toppings.");
    }

}

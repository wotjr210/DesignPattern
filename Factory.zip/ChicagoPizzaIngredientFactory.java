package Factory;

/**
 * CLass Name : ChicagoPizzaIngredientFactory
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-20     wotjr    최초생성
 */

public class ChicagoPizzaIngredientFactory implements PizzaIngredientFactory {
    @Override
    public Dough createDough() {
        Dough dough =  new ThickCrustDough();
        return dough;
    }

    @Override
    public Sauce createSauce() {
        Sauce sauce = new PlumTomatoSauce();
        return sauce;
    }

    @Override
    public Cheese createCheese() {
        Cheese cheese = new MozzarellaCheese();
        return cheese;
    }

    @Override
    public Veggies[] createVaggies() {
        Veggies veggies[] = { new Garlic(), new Mushroom(), new Onion()};
        for ( Veggies v : veggies){
        }
        return veggies;
    }

    @Override
    public Clams createClams() {
        Clams clams = new FrozenClams();
        return clams;
    }
}

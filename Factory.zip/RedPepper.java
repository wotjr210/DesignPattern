package Factory;

/**
 * CLass Name : RedPepper
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-20     wotjr    최초생성
 */

public class RedPepper implements Veggies {

    public RedPepper() {
        System.out.println("Add RedPepper Toppings.");
    }

}

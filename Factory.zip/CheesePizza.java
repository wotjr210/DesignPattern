package Factory;

/**
 * CLass Name : CheesePizza
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-20     wotjr    최초생성
 */

public class CheesePizza extends Pizza {
    PizzaIngredientFactory ingredientFactory;

    public CheesePizza(PizzaIngredientFactory ingredientFactory) {
        this.ingredientFactory = ingredientFactory;
    }

    @Override
    void prepare() {
        System.out.println("Preparing " + name);
        dough = ingredientFactory.createDough();
        sauce = ingredientFactory.createSauce();
        cheese = ingredientFactory.createCheese();
       /* for(Veggies v : veggies){
            v.addVeggies();
        }*/
    }
}

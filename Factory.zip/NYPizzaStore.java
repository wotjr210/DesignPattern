package Factory;

/**
 * CLass Name : NYPizzaStore
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-19     wotjr    최초생성
 */

public class NYPizzaStore extends PizzaStore {

    @Override
    public Pizza cratePizza(String type) {
        Pizza pizza = null;

        if( "cheese".equals(type) ){
            pizza = new CheesePizza(new NYPizzaIngredientFactory());
            pizza.setName("New York Style Cheese Pizza.");
        }

        return pizza;
    }
}

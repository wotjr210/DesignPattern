package Factory;

/**
 * CLass Name : ChicagoPizzaStore
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-19     wotjr    최초생성
 */

public class ChicagoPizzaStore extends PizzaStore {

    @Override
    protected Pizza cratePizza(String type) {
        Pizza pizza = null;
        if( "cheese".equals(type) ){
            pizza = new CheesePizza(new ChicagoPizzaIngredientFactory());
            pizza.setName("Chicago Style Cheese Pizza.");
        }
        return pizza;
    }
}

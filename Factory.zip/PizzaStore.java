package Factory;

import Factory.Pizza;

/**
 * CLass Name : PizzaStore
 * Mail : wotjr210@naver.com
 * Blog :
 * Github :
 * <p>
 * Description
 * == Modification Information ==
 * Date        Author     Note
 * ----------  ---------- --------------------
 * 2020-01-19     wotjr    최초생성
 */

public abstract class PizzaStore {

    public Pizza orderPizza(String type){

        Pizza pizza = cratePizza(type);

        pizza.prepare();
        pizza.bake();
        pizza.cut();
        pizza.box();

        return  pizza;
    }

     abstract Pizza cratePizza(String type);
}
